attachmentsHelper.js
jQuery addon for qdPM to list attachments from comments in task details
http://qdpm.net/


INSTALLATION

1. Copy attachmentsHelper.js to the following location:
PROJECT_DIR\qdpm\js\helpers

2. Add this line after "<?php echo stylesheet_tag('common.css') ?>" in "PROJECT_DIR\qdpm\core\apps\qdPM\templates\layout.php":

<!-- attachmentsHelper -->
<?php echo javascript_include_tag("/js/helpers/attachmentsHelper.js"); ?>

<script type="text/javascript">
    $(document).ready(function() {
        $.fn.attachmentsHelper({
            	language: "<?php echo $sf_user->getCulture(); ?>",
            	maxVisibleAttachments: 5
        });
    });
</script>
<!-- /attachmentsHelper -->