// attachmentsHelper.js
// v0.3
// jQuery addon for qdPM to list attachments from comments in task details (http://qdpm.net/)
// author: rolandtoth (http://blog.rolandtoth.hu/post/63105934576/qdpm-attachment-list-addon)
// last update: 2013.12.11.

(function($) {
	//"use strict";
	$.fn.extend({

		attachmentsHelper: function(opt) {
		
			var defaultOptions = {
				language: 'en',
				maxVisibleAttachments: 5
			};

			switch (opt.language) {
				
				case 'hu':
				case 'hu-HU':
					var userLang = {
						showAll: 'Összes mutatása',
						more: 'további',
						collapseList: 'Lista bezárása',
						reverseSort: 'Listázás fordított sorrendben'
					};
					break;

				case 'fr':
				case 'fr-FR':
					var userLang = {
						showAll: 'Tout afficher',
						more: 'de plus',
						collapseList: 'Réduire la liste',
						reverseSort: 'Inverser le tri'
					};
					break;
				
				case 'de':
				case 'de-DE':
					var userLang = {
						showAll: 'Alle anzeigen',
						more: 'mehr',
						collapseList: 'Liste schließen',
						reverseSort: 'Liste sortieren umgekehrter'
					};
					break;
				
				case 'ru':
				case 'ru-RU':
					var userLang = {
						showAll: 'Показать все',
						more: 'больше',
						collapseList: 'Свернуть список',
						reverseSort: 'Обратная сортировка списка'
					};
					break;
				
				case 'sv':
				case 'sv-SE':
					var userLang = {
						showAll: 'Visa alla',
						more: 'flera',
						collapseList: 'Stäng listan',
						reverseSort: 'Omvänd sortera listan'
					};
					break;
				
				case 'sr':
				case 'sr-SP-Latn':
					var userLang = {
						showAll: 'Pokaži sve',
						more: 'više',
						collapseList: 'Zatvori lista',
						reverseSort: 'Obrnuto listu sortiranje'
					};
					break;
				
				case 'sr-SP-Cyrl':
					var userLang = {
						showAll: 'Покажи све',
						more: 'више',
						collapseList: 'Затвори листа',
						reverseSort: 'Обрнуто листу сортирање'
					};
					break;
					
				default:
					var userLang = {
						showAll: 'Show all',
						more: 'more',
						collapseList: 'Collapse list',
						reverseSort: 'Reverse sort list'
					};
			};

			var options = $.extend(defaultOptions, opt);
			var localization = $.extend(opt.language, userLang);

			var target = $("div#extraFieldsInDescription + div");

			var bodyAttachmentsContainer = $('<ul class="bodyAttachmentsContainer attachedList"></ul>');
			var bodyAttachments = $('#tableListing ul.attachedList li');

			if (bodyAttachments.length) {

				// set attachment list order
				var listOrder = (COOKIE.getCookie("ah_list_order") === "DESC") ? "DESC" : "";
				var bodyAttachmentItems = (listOrder === "DESC") ? $(bodyAttachments.get()) : $(bodyAttachments.get().reverse());

				bodyAttachmentItems.each(function() {
					var attachmentsDetails = $(this).parents('td').next('td').html();
					attachmentsDetails = attachmentsDetails.replace(/<br( \/)?><img.+/g, '');
					attachmentsDetails = attachmentsDetails.replace(/<br( \/)?>/g, ", ");
					attachmentsDetails = $('<span class="attachment-details">' + attachmentsDetails + '</span>');
					bodyAttachmentsContainer.append($(this).clone(true));
					bodyAttachmentsContainer.find('li').last().append(attachmentsDetails);
				})

				bodyAttachmentsContainer.find('li').children('a + a[target="_blank"]').remove();

				bodyAttachmentsContainer.css({
					'width': 'auto',
					'display': 'inline-block',
					'width': 'auto',
					'min-width': '50%',
					'max-width': '90%',
					'margin-top': '4px',
					'margin-bottom': '20px'
				});

				bodyAttachmentsContainer.find('li').css({
					'display': 'block'
				});

				bodyAttachmentsContainer.find('li').find('a:gt(0)').css({
					'width': '12px',
					'height': '12px',
					'display': 'inline-block',
					'overflow': 'hidden'
				});

				bodyAttachmentsContainer.find('span.attachment-details').css({
					'float': 'right',
					'color': '#666',
					'font-size': '11px',
					'margin-top': '5px',
					'margin-bottom': '-5px',
					'font-style': 'italic',
					'margin-right': '5px',
					'margin-left': '30px'
				});

				// ie7
				bodyAttachmentsContainer.find('span.attachment-details img').remove();

				target.after(bodyAttachmentsContainer);

				// display "Show all attachments" if there are too many attachments
				var attachmentsToggleContainer = $('<li class="attachmentsToggleContainer">');
				var attachmentsToggleBtn = $('<a href="#" title="" class="attachmentsToggleBtn btn">' + localization.showAll + '</a>');
				
				if (bodyAttachmentsContainer.children('li').length > options.maxVisibleAttachments) {

					// hide extra attachments
					bodyAttachmentsContainer.find('li:gt(' + parseInt(options.maxVisibleAttachments - 1) + ')').hide();

					// append toggle button
					attachmentsToggleContainer.append(attachmentsToggleBtn);
					bodyAttachmentsContainer.append(attachmentsToggleContainer);

					var moreItems = bodyAttachmentsContainer.children('li:gt(' + options.maxVisibleAttachments + ')').length;
					
					if (moreItems > 0) {
						// add button to change attachment list order
						
						var attachmentListOrderBtn = $('<a href="#" title="" class="reverseAttachmentsList">' + localization.reverseSort + '</a>');
						bodyAttachmentsContainer.children('li').last().append(attachmentListOrderBtn);
						
						attachmentListOrderBtn.click(function() {
							var newOrder = COOKIE.getCookie("ah_list_order");
							newOrder = (newOrder === "DESC") ? "" : "DESC";
							COOKIE.setCookie("ah_list_order", newOrder);

							bodyAttachmentsContainer.children().show();
							bodyAttachmentsContainer.prepend(bodyAttachmentsContainer.children().not('.attachmentsToggleContainer').get().reverse());
							// only hide elements if list is not expanded
							if (attachmentsToggleBtn.text() != localization.collapseList) {
								bodyAttachmentsContainer.find('li:gt(' + parseInt(options.maxVisibleAttachments - 1) + ')').not('.attachmentsToggleContainer').hide();
							}

							return false;
						})
						
						attachmentListOrderBtn.css({
							'position': 'relative',
							'float': 'right',
							'padding': '4px',
							'display': 'block',
							'font-style': 'italic',
							'font-size': '11px',
							'margin': '1px 1px 0px'
						});
						
						// show more items button						
						localization.showAll = localization.showAll + ' (' + moreItems + ' ' + localization.more + ')';
					}

					attachmentsToggleBtn.text(localization.showAll);

					attachmentsToggleBtn.click(function() {

						if (bodyAttachmentsContainer.find('li:eq(' + parseInt(options.maxVisibleAttachments) + ')').is(':visible')) {
							// hide items
							bodyAttachmentsContainer.find('li:gt(' + parseInt(options.maxVisibleAttachments - 1) + ')').not('.attachmentsToggleContainer').hide();
							attachmentsToggleBtn.text(localization.showAll);
							// scroll to top
							$('html,body').animate({
								scrollTop: bodyAttachmentsContainer.offset().top - 40
							}, 700);
						} else {
							// show items
							bodyAttachmentsContainer.children('li').show();
							attachmentsToggleBtn.text(localization.collapseList);
						}

						return false;
					});
				}

				// format here to avoid items > options.maxVisibleAttachments to be always visible
				bodyAttachmentsContainer.find('li').css({
					'background-color': 'rgba(0, 0, 0, 0.05)',
					'position': 'relative',
					'margin-bottom': '-1px',
					'margin-top': '0',
					'float': 'left',
					'width': '100%',
					'clear': 'both'
				});

			}
		}

	});
})(jQuery);

// cookie declaration
var COOKIE = {
	// Function for setting a cookie:
	setCookie: function(name, value) {

		// Begin creating the value string:
		var str = encodeURIComponent(name) + '=' + encodeURIComponent(value);

		// Add the expiration:
		str += ';expires=' + expire.toGMTString() + ';path=/';
		//str += ';path=/';

		// Create the cookie:
		document.cookie = str;

	},
	// End of setCookie() function.

	// Function for retrieving a cookie value:
	getCookie: function(name) {

		// Useful to know how long the cookie name is:
		var len = name.length;

		// Split the cookie value:
		var cookies = document.cookie.split(';');

		// Loop through the values:
		for (var i = 0, count = cookies.length; i < count; i++) {

			// Lop off an initial space:
			var value = (cookies[i].slice(0, 1) == ' ') ? cookies[i].slice(1) : cookies[i];

			// Decode the value:
			value = decodeURIComponent(value);

			// Check if this iteration matches the name:
			if (value.slice(0, len) == name) {
				// Return the part after the equals sign:
				return value.split('=')[1];
			} // End of IF.
		} // End of FOR loop.

		// Return false if nothing's been returned yet:
		return false;

	},
	// End of getCookie() function.

	// Function for deleting cookies:
	deleteCookie: function(name) {
		//         document.cookie = encodeURIComponent(name) + '=;expires=Thu, 01-Jan-1970 00:00:01 GMT' + ';path=/';
		document.cookie = encodeURIComponent(name) + '=;path=/';
	} // End of deleteCookie() function.
}; // End of COOKIE declaration.

// cookie expiration
var expire = new Date();
expire.setDate(expire.getDate() + 9999);