************************************************************
	NSIScons for Total Commander & Double Commander
************************************************************

NSIScons helps you using NSIS constants (e.g. $WINDIR, $HISTORY, $LOCALAPPDATA) in Total Commander's or Double Commander's button bar.
By clicking on an NSIScons button the target panel of these applications will navigate to the corresponding location.

--------------------------------------------------
	LICENCE
--------------------------------------------------
NSIScons is provided "as-is" without warranty of any kind, express, implied or otherwise,
including without limitation, any warranty of merchantability or fitness for a particular purpose.
In no event shall the author of this software be held liable for data loss, damages,
loss of profits or any other kind of loss while using or misusing this software.

--------------------------------------------------
	USAGE INFORMATION
--------------------------------------------------
1. Copy NSIScons folder to a folder of your choice.
2. Edit NSIScons.ini to set Total Commander / Doubler Commander path and commandline options.
3. Import example setups (A) or configure buttons manually (B) 

A) Importing example setups

	Total Commander:
		A1) copy "Examples\NSIScons.bar" to your TC directory
		A2) replace path of NSIScons.exe in NSIScons.bar
		A3) right-click on the button bar and select "Change.."
		A4) add new button with the "Add" button
		A5) for the Command, click on "Change >>" and select "Add Subbar >>"
		A6) browse for "NSIScons.bar" in your TC directory
		A7) click OK, this will get you to the main button bar dialog
		A8) set the icon of the new button to "C:\totalcmd\tools\NSIScons\NSIScons.exe" (change path if needed)
		A9) Check "Show as menu" and hit OK to save

	Double Commander:
		A1) replace path of NSIScons.exe in "Examples\doublecmd.txt"
		A2) copy contents of doublecmd.txt to clipboard and paste it to DC's toolbar via the right-click context menu

B) Manual configuration

	Add a button to your button bar with the following settings:
	
	Total Commander: 
		- Command: "%commander_path%\tools\NSIScons\NSIScons.exe"
		- Parameter: CDBURN_AREA
		- Icon file: %commander_path%\tools\NSIScons\NSIScons.exe
		- Tooltip: CD Burn Area

	Double Commander:
		- Tooltip: CD Burn Area
		- Command: %commander_path%\tools\NSIScons\NSIScons.exe
		- Parameters: CDBURN_AREA

Remember to change paths to NSIScons.exe if needed.
For system icon reference visit http://diymediahome.org/windows-icons-reference-list-with-details-locations-images/ website.

--------------------------------------------------
	SUPPORTED PARAMETERS
--------------------------------------------------
1. NSIS constants
- ADMINTOOLS
- ADMINTOOLSALLUSERS
- APPDATA
- APPDATAALLUSERS
- CDBURN_AREA
- COMMONFILES
- COMMONFILES32
- COMMONFILES64
- COOKIES
- DESKTOP
- DESKTOPALLUSERS
- DOCUMENTS
- DOCUMENTSALLUSERS
- EXEDIR
- EXEPATH
- FAVORITES
- FAVORITESALLUSERS
- FONTS
- HISTORY
- INTERNET_CACHE
- LOCALAPPDATA
- MUSIC
- MUSICALLUSERS
- NETHOOD
- NSISDIR
- {NSISDIR}
- PICTURES
- PICTURESALLUSERS
- PRINTHOOD
- PROFILE
- PROGRAMFILES
- PROGRAMFILES32
- PROGRAMFILES64
- QUICKLAUNCH
- RECENT
- RESOURCES
- RESOURCES_LOCALIZED
- SENDTO
- SMPROGRAMS
- SMPROGRAMSALLUSERS
- SMSTARTUP
- SMSTARTUPALLUSERS
- STARTMENU
- STARTMENUALLUSERS
- SYSDIR
- TEMP
- TEMPLATES
- TEMPLATESALLUSERS
- VIDEOS
- VIDEOSALLUSERS
- WINDIR

See descriptions in NSIS Help: http://nsis.sourceforge.net/Docs/Chapter4.html#4.2.3
Note that some constants may be unavailable on your OS.

2. Environment variables

If no matching NSIS constant is found NSIScons attempts to resolve the parameter as an environment variable.
When adding environment variables make sure NOT to add percentage characters to the parameter:
- good:  NSIScons.exe HOMEDRIVE
- bad: NSIScons.exe %HOMEDRIVE%


--------------------------------------------------
	HELP
--------------------------------------------------
If you have any questions contact me at contact@rolandtoth.hu.


--------------------------------------------------
	CREDITS
--------------------------------------------------
- icons: Yathosho (http://forums.winamp.com/showthread.php?t=276366)


--------------------------------------------------
	CHANGELOG
--------------------------------------------------
v0.2 - June 01, 2014
- NEW: support for Double Commander (http://doublecmd.sourceforge.net/)
- NEW: examples for Total Commander / Double Commander with system icons (see README.txt)
- NEW: attempt to resolve parameter as environment variable if no matching NSIS constant found
- updated documentation
- main icon size fixes
- minor fixes

v0.1 - December 15, 2011
- initial release


************************************************************
	END OF PATIENCE TO WRITE THIS README FILE
************************************************************